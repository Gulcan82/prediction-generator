import {GlobalConfigInstance} from './lib/config';

export * from './lib/core';
export * from './clients/all';
export var config: GlobalConfigInstance

export as namespace AWS;